
var serverlessSDK = require('./serverless_sdk/index.js');
serverlessSDK = new serverlessSDK({
  orgId: 'snikfernando',
  applicationName: 'pruebaaws',
  appUid: 'P09Ylr75Y5jy8L3w0V',
  orgUid: '48653ebe-a02a-4f22-8556-ce2466c43bff',
  deploymentUid: 'ec216a27-fc9a-4ff3-8531-3b9c560a5d39',
  serviceName: 'pruebaaws',
  shouldLogMeta: true,
  shouldCompressLogs: true,
  disableAwsSpans: false,
  disableHttpSpans: false,
  stageName: 'dev',
  serverlessPlatformStage: 'prod',
  devModeEnabled: false,
  accessKey: null,
  pluginVersion: '5.4.3',
  disableFrameworksInstrumentation: false
});

const handlerWrapperArgs = { functionName: 'pruebaaws-dev-awsprueba', timeout: 6 };

try {
  const userHandler = require('./handler.js');
  module.exports.handler = serverlessSDK.handler(userHandler.handler, handlerWrapperArgs);
} catch (error) {
  module.exports.handler = serverlessSDK.handler(() => { throw error }, handlerWrapperArgs);
}